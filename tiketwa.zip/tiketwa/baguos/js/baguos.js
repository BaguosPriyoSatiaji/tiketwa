//datatable
$(document).ready(function() {
    var table = $('#example').DataTable( {
        responsive: true
       
    } );
 
    new $.fn.dataTable.FixedHeader( table );
});

  // $(document).ready(function () {
  //               $('#table_id').DataTable({
  //                   // script untuk membuat export data 
  //                   dom: 'Bfrtip',
  //                   buttons: [
  //                       'copy', 'csv', 'excel', 'pdf', 'print'
  //                   ]
  //               })
  //           });


// <script type="text/javascript"> 
//     $(document).ready(function () {
//         $('#table-datatables').DataTable({
//             dom: 'Bfrtip',
//             buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
//         });
//     });
// </script>

//Jam
window.onload = function() {
  jam();
}
function jam() {
 var e = document.getElementById('jam'),
     d = new Date(),
     h, m, s;
     h = d.getHours();
     m = set(d.getMinutes());
     s = set(d.getSeconds());

     e.innerHTML = h + ':' + m + ':' + s;

     setTimeout('jam()', 1000);
 }

function set(e) {
     e = e < 10 ? '0' + e : e;
     return e;
 }
               
