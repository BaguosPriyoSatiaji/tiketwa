<?php
defined('BASEPATH') or exit('No direct script access allowed');
class M_fungsi extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->database();
    }

    public function dtabel()
    {
        $barang = $this->db->query("SELECT * FROM dataku ORDER BY id DESC");
        return $barang->result();
    }

    public function dtabeln()
    {
        $barang = $this->db->query("SELECT * FROM dataku ORDER BY tgl DESC limit 1");
        return $barang->result();
    }

    public function tdata()
    {
        $nomor = $this->input->post('nomor');
        $po = $this->input->post('po');
        $do = $this->input->post('do');
        $ipku = $this->input->post('ipku');
        $data = array(
            'nomor' => $nomor,
            'po' => $po,
            'do' => $do,
            'ipku' => $ipku,
        );
        $this->db->set($data);
        $this->db->insert('dataku');
    }

    public function edata($id)
    {
        $nomor = $this->input->post('nomor');
        $po = $this->input->post('po');
        $do = $this->input->post('do');
        $ipku = $this->input->post('ipku');
        $data = array(
            'nomor' => $nomor,
            'po' => $po,
            'do' => $do,
            'ipku' => $ipku,
        );
        $this->db->where('id', $id);
        $this->db->set($data);
        $this->db->update('dataku');
    }


    public function deletedata($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('dataku');
    }
}
