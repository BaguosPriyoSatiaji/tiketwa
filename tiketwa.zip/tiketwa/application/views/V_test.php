<!DOCTYPE html>
<!DOCTYPE html>
<html>

<head>
    <title>Contoh Pop Up Otomatis dengan Modal Bootstrap 4.6</title>
    <!-- Tambahkan link CSS dan JavaScript untuk Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.3/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.1/js/bootstrap.min.js"></script>
</head>

<body>
    <!-- Tambahkan modal dengan id myModal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Header modal -->
                <div class="modal-header">
                    <h4 class="modal-title">Judul Pop Up</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Body modal -->
                <div class="modal-body">
                    <p>Isi pesan pop up di sini.</p>
                </div>

                <!-- Footer modal -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                </div>

            </div>
        </div>
    </div>

    <!-- Tambahkan kode JavaScript untuk memunculkan modal secara otomatis -->
    <script>
        $(document).ready(function() {
            $("#myModal").modal('show');
        });
    </script>
</body>

</html>