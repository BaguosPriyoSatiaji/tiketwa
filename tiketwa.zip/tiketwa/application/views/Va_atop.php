<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous"> -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jq-3.6.0/dt-1.13.2/fc-4.2.1/fh-3.3.1/r-2.4.0/datatables.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />


    <!-- Tambahkan link CSS dan JavaScript untuk Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.1/js/bootstrap.min.js"></script>
    <link rel="shortcut icon" href="<?= Base_url('') ?>baguos/logo/bnd.png">

    <title>Kirim WA</title>

    <br>
    <div class="container">
        <div class="row alert-success ">
            <div class="col-10 mt-1">
                <a href="<?= Base_url('') ?>">
                    <h2 class=" text-left">
                        <img src="<?= Base_url('') ?>baguos/logo/bndv2.png" style="width: 150px;">
                    </h2>
                </a>
            </div>
            <div class="col mt-3">
                <h6 style="color:#6c757d;">Jam : <b><span id="jam" style="font-size:24"></span></b> WIB</h6>
            </div>
        </div>

    </div>
</head>

<body>