<?php foreach ($tabeln as $n) : echo ""; ?>
    <div class="modal" id="myModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Header modal -->
                <div class="modal-header">
                    <h4 class="modal-title">Validasi Data</h4>
                    <a href="<?= site_url('Home') ?>" class="btn btn-warning btn-sm">Tutup</a>
                    <a href="<?= site_url('Home/deletedata/') ?><?= $n->id ?>" class="btn btn-danger">Batalkan</a>
                </div>

                <!-- Body modal -->
                <div class="modal-body">
                    <form action="<?= site_url('Home/edata') ?>/<?= $n->id ?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Nomor Telp</label>
                            <h7 style="color:red;">*</h7>
                            <input type="number" class="form-control" name="nomor" placeholder="Masukan No Wa" required="required" value="<?= $n->nomor ?>">
                            <small id="emailHelp" class="form-text text-muted">Silahkan Masukan Nomor WA yang Sesuai</small>
                        </div>
                        <div class="form-group">
                            <label>PO</label>
                            <input type="text" class="form-control" name="po" placeholder="Masukan PO" value="<?= $n->po ?>">
                        </div>
                        <div class=" form-group">
                            <label>DO</label>
                            <h7 style="color:red;">*</h7>
                            <input type="text" class="form-control" name="do" placeholder="Masukan DO" required="required" value="<?= $n->do ?>">
                        </div>
                        <div class="form-group hide">
                            <input type="text" class="form-control" name="ipku" readonly value="<?php
                                                                                                $ip_address = $_SERVER['REMOTE_ADDR'];
                                                                                                echo "" . $ip_address;
                                                                                                ?>.<?php
                                                                                                    $user_agent = $_SERVER['HTTP_USER_AGENT'];

                                                                                                    if (strpos($user_agent, 'MSIE') !== FALSE) {
                                                                                                        $browser = 'Internet Explorer';
                                                                                                    } elseif (strpos($user_agent, 'Firefox') !== FALSE) {
                                                                                                        $browser = 'Mozilla Firefox';
                                                                                                    } elseif (strpos($user_agent, 'Chrome') !== FALSE) {
                                                                                                        $browser = 'Google Chrome';
                                                                                                    } elseif (strpos($user_agent, 'Safari') !== FALSE) {
                                                                                                        $browser = 'Apple Safari';
                                                                                                    } elseif (strpos($user_agent, 'Opera Mini') !== FALSE) {
                                                                                                        $browser = 'Opera Mini';
                                                                                                    } else {
                                                                                                        $browser = 'unknown';
                                                                                                    }

                                                                                                    echo "" . $browser;
                                                                                                    ?>">
                        </div>
                        <button type="submit" class="btn btn-warning btn-sm btn-block"><i class="fa-regular fa-pen-to-square"></i> Update Data <i class="fa-regular fa-pen-to-square"></i></button>
                    </form>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>
                            <b>Nomor yang dituju : <?= $n->nomor ?></b><br>
                            Konsumen PT. Berkat Niaga Dunia Yang Terhormat,<br>
                            <br>
                            Terima kasih sudah berbelanja di PT. Berkat Niaga Dunia untuk keperluan alat - alat safety anda.<br>
                            Dengan ini kami informasikan bahwa pesanan anda dengan<br>
                            <br>
                            <b> No PO : <?= $n->po ?></b><br>
                            <b> No DO : <?= $n->do ?></b><br>
                            <br>
                            sudah selesai di proses dan siap untuk diambil.<br>
                            Untuk pengambilan, hari senin - jumat maksimal jam 16:00 WIB<br>
                            <br>
                            Terima Kasih,<br>
                            PT. Berkat Niaga Dunia
                        </label>
                        <a type="submit" class="btn btn-success btn-lg btn-block" href="https://web.whatsapp.com/send?phone=62<?= $n->nomor ?>&text=Konsumen%20PT.%20Berkat%20Niaga%20Dunia%20Yang%20Terhormat%2C%20%0A%0ATerima%20kasih%20sudah%20berbelanja%20di%20PT.%20Berkat%20Niaga%20Dunia%20untuk%20keperluan%20alat%20-%20alat%20safety%20anda.%20%0ADengan%20ini%20kami%20informasikan%20bahwa%20pesanan%20anda%20dengan%20%0A%0A*No%20PO%20%3A%20<?= $n->po ?>*%0A*No%20DO%20%3A%20<?= $n->do ?>*%0A%0Asudah%20selesai%20di%20proses%20dan%20siap%20untuk%20diambil.%20%0AUntuk%20pengambilan,%20hari%20senin%20-%20jumat%20maksimal%20jam%2016%3A00%20WIB%0A%0ATerima%20Kasih%2C%20%0APT.%20Berkat%20Niaga%20Dunia" target="_blank"><i class="fa-brands fa-whatsapp"></i> Kirim Whatsapp WEB <i class="fa-brands fa-whatsapp"></i></a>
                        <!-- <a type="submit" class="btn btn-success btn-sm btn-block" href="https://api.whatsapp.com/send?phone=62<?= $n->nomor ?>&text=Konsumen%20PT.%20Berkat%20Niaga%20Dunia%20Yang%20Terhormat%2C%20%0A%0ATerima%20kasih%20sudah%20berbelanja%20di%20PT.%20Berkat%20Niaga%20Dunia%20untuk%20keperluan%20alat%20-%20alat%20safety%20anda.%20%0ADengan%20ini%20kami%20informasikan%20bahwa%20pesanan%20anda%20dengan%20%0A%0A*No%20PO%20%3A%20<?= $n->po ?>*%0A*No%20DO%20%3A%20<?= $n->do ?>*%0A%0Asudah%20selesai%20di%20proses%20dan%20siap%20untuk%20diambil.%20%0AUntuk%20pengambilan,%20hari%20senin%20-%20jumat%20maksimal%20jam%2016%3A00%20WIB%0A%0ATerima%20Kasih%2C%20%0APT.%20Berkat%20Niaga%20Dunia" target="_blank"><i class="fa-brands fa-whatsapp"></i> Kirim Whatsapp APP <i class="fa-brands fa-whatsapp"></i></a> -->
                        <a href="<?= site_url('Home') ?>" class="btn btn-outline-danger btn-sm btn-block">Jika Sudah Terkirim Silahkan Klik <button type="button" class="btn btn-warning btn-sm">Tutup</button> <i class="fa-solid fa-exclamation"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<script>
    $(document).ready(function() {
        $("#myModal").modal('show');
    });
</script>

<br>
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <form action="<?= site_url('Home/tdata') ?>" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Nomor Telp</label>
                    <h7 style="color:red;">*</h7>
                    <input type="number" class="form-control" name="nomor" placeholder="Masukan No Wa" required="required">
                    <small id="emailHelp" class="form-text text-muted">Silahkan Masukan Nomor WA yang Sesuai</small>
                </div>
                <div class="form-group">
                    <label>PO</label>
                    <h7 style="color:red;">*</h7>
                    <input type="text" class="form-control" name="po" placeholder="Masukan PO" required="required">
                </div>
                <div class="form-group">
                    <label>DO</label>
                    <h7 style="color:red;">*</h7>
                    <input type="text" class="form-control" name="do" placeholder="Masukan DO" required="required">
                </div>
                <button type="submit" class="btn btn-primary btn-lg btn-block">Validasi <i class="fa-solid fa-check-double"></i></button>
            </form>

        </div>
        <div class="col-sm-8">
            <!-- <div class="card-body"> -->
            <table class="table table-striped" id="example">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nomor WA</th>
                        <th scope="col">PO</th>
                        <th scope="col">DO</th>
                        <th scope="col">Date & Time</th>
                        <th scope="col">Opsi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $no = 0;
                    foreach ($tabela as $i) : echo "";
                        $no++ ?>
                        <tr>
                            <th><?= $no ?> </th>
                            <td><?= $i->nomor ?></td>
                            <td><?= $i->po ?></td>
                            <td><?= $i->do ?></td>
                            <td><?= $i->tgl ?></td>
                            <td>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?= $i->id ?>">
                                    <i class="fa fa-circle-exclamation"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <!-- </div> -->
        </div>
    </div>
</div>

<style>
    .hide {
        display: none;
    }
</style>