<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_fungsi');
        $this->load->helper('url', 'form', 'download');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['tabela'] = $this->M_fungsi->dtabel();
        $data['tabeln'] = $this->M_fungsi->dtabeln();
        $this->load->view('Va_atop');
        $this->load->view('Va_home', $data);
        $this->load->view('Va_adown');
    }

    public function tdata()
    {
        $this->M_fungsi->tdata();
        redirect('Home/xdatax');
    }

    public function edata($id)
    {
        $this->M_fungsi->edata($id);
        redirect('Home/xdatax');
    }

    public function tkirim()
    {
        $this->M_fungsi->tkirim();
        redirect('Home');
    }

    public function xdatax()
    {
        $data['tabela'] = $this->M_fungsi->dtabel();
        $data['tabeln'] = $this->M_fungsi->dtabeln();
        $this->load->view('Va_atop');
        $this->load->view('Va_homex', $data);
        $this->load->view('Va_adown');
    }

    public function deletedata($id)
    {
        $this->M_fungsi->deletedata($id);
        redirect('Home');
    }
}
